# SalesScope — Next.js Sales Analytics Dashboard

SalesScope is a simple, internship-ready sales analytics dashboard built with **Next.js 15, TypeScript, Tailwind CSS and Recharts**.

The project demonstrates an **Atomic Design** component structure:

- **Atoms** — reusable `Button`, `Input`, and `Badge`
- **Molecules** — `StatCard` and `ChartCard`
- **Organisms** — `SalesChart` and the complete `Dashboard`
- **Pages** — the `/dashboard` page composes the dashboard organism

## Features

- Sales dashboard for **2022, 2023 and 2024**
- Mock monthly sales dataset
- Bar, line and pie charts using Recharts
- Custom sales-threshold filter
- Year selector
- Total sales, average sales and peak sales KPI cards
- Responsive Tailwind CSS layout
- Clean TypeScript types
- API-ready separation between data and UI
- Simple landing page and dedicated empty/composition dashboard page
- Internship-friendly README and project structure

## Data source note

The dashboard data is **mocked for this project** rather than copied directly from a Kaggle file. The data model and retail-sales context are inspired by public Kaggle sales datasets, including the Kaggle Retail Sales Dataset and other sales datasets.

Reference examples:
- Kaggle Retail Sales Dataset: https://www.kaggle.com/code/abbas829/comprehensive-eda-report-retail-sales-dataset/input
- Kaggle Sample Country Sales Dataset: https://www.kaggle.com/code/kerneler/starter-sample-country-sales-dataset-47c7c5c5-5/input
- Kaggle Amazon Sales & Trading Insights Dataset (2024): https://www.kaggle.com/datasets/nalisha/amazon-sales-and-trading-insights-dataset-2024/data

No claim is made that the dashboard numbers are real business figures.

## Tech stack

- Next.js 15
- React 19
- TypeScript
- Tailwind CSS
- Recharts
- ESLint

## Project structure

```text
sales-analytics-dashboard/
├── app/
│   ├── dashboard/
│   │   └── page.tsx
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── atoms/
│   │   ├── badge.tsx
│   │   ├── button.tsx
│   │   └── input.tsx
│   ├── molecules/
│   │   ├── chart-card.tsx
│   │   └── stat-card.tsx
│   └── organisms/
│       ├── dashboard.tsx
│       └── sales-chart.tsx
├── lib/
│   ├── sales-data.ts
│   └── types.ts
├── eslint.config.mjs
├── next.config.ts
├── package.json
├── postcss.config.mjs
├── tailwind.config.ts
├── tsconfig.json
└── README.md
```

## Setup

### 1. Requirements

Install:

- Node.js 20 LTS or newer
- npm
- VS Code

### 2. Install dependencies

```bash
npm install
```

### 3. Start development server

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

Then open:

```text
http://localhost:3000/dashboard
```

### 4. Production build

```bash
npm run build
npm start
```

## How the dashboard works

1. `lib/sales-data.ts` contains the mock sales data.
2. The dashboard selects one year from 2022–2024.
3. The threshold input filters monthly records.
4. KPI cards calculate total, average and peak values from the filtered records.
5. `SalesChart` renders the selected data with Recharts.
6. Users can switch between bar, line and pie visualizations.

## API integration roadmap

The current dashboard intentionally keeps data local so it works immediately after `npm install`.

For a production version, replace the local `salesData` import with a typed API service:

```text
API → typed response → dashboard state → filter → chart components
```

A future endpoint could return:

```json
{
  "year": 2024,
  "sales": [
    { "month": "Jan", "sales": 26500 }
  ]
}
```

This keeps the presentation components independent from the data source.

## GitHub setup

Create a new empty GitHub repository, then run these commands from the project folder:

```bash
git init
git add .
git commit -m "feat: build sales analytics dashboard"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do not commit `node_modules` or `.next`; they are generated locally.

## Internship value

This project demonstrates:

- Component architecture
- Atomic Design thinking
- TypeScript typing
- Responsive UI development
- Data visualization
- State management with React hooks
- Client-side filtering
- Reusable chart components
- Separation of data, types and presentation
- A clear path from mock data to API integration

## Suggested GitHub repository name

`nextjs-sales-analytics-dashboard`

## License

Educational portfolio project.
