import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SalesScope | Sales Analytics Dashboard",
  description: "A structured Next.js sales analytics dashboard using mock retail data.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}