import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-950 px-6 py-16 text-white">
      <div className="mx-auto max-w-5xl">
        <span className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-sm text-slate-300">
          Next.js 15 · TypeScript · Tailwind CSS · Recharts
        </span>
        <h1 className="mt-8 max-w-3xl text-5xl font-bold tracking-tight sm:text-6xl">
          SalesScope
          <span className="block text-slate-400">A clean sales analytics experience.</span>
        </h1>
        <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
          Explore yearly sales for 2022, 2023 and 2024 with threshold filtering and
          switchable chart views.
        </p>
        <Link
          href="/dashboard"
          className="mt-10 inline-flex rounded-xl bg-white px-6 py-3 font-semibold text-slate-950 transition hover:bg-slate-200"
        >
          Open Dashboard
        </Link>
      </div>
    </main>
  );
}