import { ButtonHTMLAttributes } from "react";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  active?: boolean;
};

export function Button({ active = false, className = "", ...props }: ButtonProps) {
  return (
    <button
      className={`rounded-lg px-3 py-2 text-sm font-semibold transition ${
        active
          ? "bg-slate-900 text-white"
          : "bg-slate-100 text-slate-600 hover:bg-slate-200"
      } ${className}`}
      {...props}
    />
  );
}