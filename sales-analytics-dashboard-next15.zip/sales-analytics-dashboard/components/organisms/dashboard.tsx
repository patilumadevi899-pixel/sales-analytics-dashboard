 "use client";

import { useMemo, useState } from "react";
import { Button } from "@/components/atoms/button";
import { Input } from "@/components/atoms/input";
import { ChartCard } from "@/components/molecules/chart-card";
import { StatCard } from "@/components/molecules/stat-card";
import { SalesChart } from "@/components/organisms/sales-chart";
import { salesData } from "@/lib/sales-data";
import { ChartType, YearKey } from "@/lib/types";

const years: YearKey[] = ["2024", "2023", "2022"];

const money = (value: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);

export function Dashboard() {
  const [year, setYear] = useState<YearKey>("2024");
  const [chartType, setChartType] = useState<ChartType>("bar");
  const [threshold, setThreshold] = useState("0");

  const filteredData = useMemo(() => {
    const limit = Number(threshold) || 0;
    return salesData[year].filter((item) => item.sales >= limit);
  }, [threshold, year]);

  const totalSales = filteredData.reduce((sum, item) => sum + item.sales, 0);
  const average = filteredData.length ? totalSales / filteredData.length : 0;
  const peak = filteredData.length ? Math.max(...filteredData.map((item) => item.sales)) : 0;

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <header className="rounded-3xl bg-slate-950 p-7 text-white shadow-soft sm:p-9">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-slate-400">
                SalesScope / Dashboard
              </p>
              <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">
                Sales performance workspace
              </h1>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300">
                A structured dashboard built with Atomic Design principles. Select a year,
                set a sales threshold and compare chart representations.
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 px-5 py-4">
              <p className="text-xs text-slate-400">Selected year</p>
              <p className="mt-1 text-2xl font-bold">{year}</p>
            </div>
          </div>
        </header>

        <section className="mt-6 grid gap-3 sm:grid-cols-3">
          <StatCard label="Filtered sales" value={money(totalSales)} helper={`${filteredData.length} months included`} />
          <StatCard label="Monthly average" value={money(average)} helper="Based on filtered records" />
          <StatCard label="Peak month" value={money(peak)} helper="Highest visible monthly sale" />
        </section>

        <section className="mt-6 grid gap-4 lg:grid-cols-[1fr_auto]">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft">
            <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
              Minimum sales threshold
            </label>
            <Input
              type="number"
              min="0"
              value={threshold}
              onChange={(e) => setThreshold(e.target.value)}
              placeholder="Example: 30000"
            />
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft">
            <p className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-500">Year</p>
            <div className="flex gap-2">
              {years.map((item) => (
                <Button key={item} active={year === item} onClick={() => setYear(item)}>
                  {item}
                </Button>
              ))}
            </div>
          </div>
        </section>

        <section className="mt-6">
          <ChartCard
            title={`${year} sales trend`}
            description="Mock retail sales data inspired by public Kaggle sales datasets."
          >
            <div className="mb-4 flex flex-wrap gap-2">
              {(["bar", "line", "pie"] as ChartType[]).map((item) => (
                <Button key={item} active={chartType === item} onClick={() => setChartType(item)}>
                  {item.charAt(0).toUpperCase() + item.slice(1)} chart
                </Button>
              ))}
            </div>
            {filteredData.length ? (
              <SalesChart data={filteredData} type={chartType} />
            ) : (
              <div className="flex h-[330px] items-center justify-center rounded-xl bg-slate-50 text-sm text-slate-500">
                No sales meet this threshold. Lower the value to view data.
              </div>
            )}
          </ChartCard>
        </section>

        <footer className="mt-6 rounded-2xl border border-slate-200 bg-white p-5 text-sm text-slate-500 shadow-soft">
          <strong className="text-slate-800">Data note:</strong> The project uses intentionally
          mocked monthly values for demonstration. The structure can be connected to a real API
          without changing the chart interface.
        </footer>
      </div>
    </main>
  );
}