 "use client";

import {
  Bar,
  BarChart,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { ChartType, SalesRecord } from "@/lib/types";

export function SalesChart({
  data,
  type,
}: {
  data: SalesRecord[];
  type: ChartType;
}) {
  if (type === "pie") {
    return (
      <div className="h-[330px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="sales"
              nameKey="month"
              cx="50%"
              cy="50%"
              outerRadius={105}
              innerRadius={58}
              paddingAngle={2}
              label={({ month }) => month}
            >
              {data.map((item, index) => (
                <Cell key={item.month} fill={`hsl(${210 + index * 9} 70% ${45 + (index % 3) * 8}%)`} />
              ))}
            </Pie>
            <Tooltip formatter={(value: number) => [`₹${value.toLocaleString()}`, "Sales"]} />
          </PieChart>
        </ResponsiveContainer>
      </div>
    );
  }

  return (
    <div className="h-[330px]">
      <ResponsiveContainer width="100%" height="100%">
        {type === "line" ? (
          <LineChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <XAxis dataKey="month" tickLine={false} axisLine={false} />
            <YAxis tickLine={false} axisLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
            <Tooltip formatter={(value: number) => [`₹${value.toLocaleString()}`, "Sales"]} />
            <Line type="monotone" dataKey="sales" stroke="#0f172a" strokeWidth={3} dot={{ r: 3 }} />
          </LineChart>
        ) : (
          <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <XAxis dataKey="month" tickLine={false} axisLine={false} />
            <YAxis tickLine={false} axisLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
            <Tooltip formatter={(value: number) => [`₹${value.toLocaleString()}`, "Sales"]} />
            <Bar dataKey="sales" radius={[6, 6, 0, 0]} fill="#0f172a" />
          </BarChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}