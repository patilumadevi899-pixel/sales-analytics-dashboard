import { SalesDataset } from "./types";

export const salesData: SalesDataset = {
  "2022": [
    { month: "Jan", sales: 18400 }, { month: "Feb", sales: 21200 },
    { month: "Mar", sales: 19800 }, { month: "Apr", sales: 23500 },
    { month: "May", sales: 24700 }, { month: "Jun", sales: 22600 },
    { month: "Jul", sales: 26100 }, { month: "Aug", sales: 25300 },
    { month: "Sep", sales: 27800 }, { month: "Oct", sales: 29400 },
    { month: "Nov", sales: 32100 }, { month: "Dec", sales: 35600 }
  ],
  "2023": [
    { month: "Jan", sales: 22100 }, { month: "Feb", sales: 23900 },
    { month: "Mar", sales: 25400 }, { month: "Apr", sales: 26800 },
    { month: "May", sales: 28300 }, { month: "Jun", sales: 27600 },
    { month: "Jul", sales: 30100 }, { month: "Aug", sales: 31800 },
    { month: "Sep", sales: 32700 }, { month: "Oct", sales: 34900 },
    { month: "Nov", sales: 38100 }, { month: "Dec", sales: 42500 }
  ],
  "2024": [
    { month: "Jan", sales: 26500 }, { month: "Feb", sales: 28200 },
    { month: "Mar", sales: 29700 }, { month: "Apr", sales: 31500 },
    { month: "May", sales: 33100 }, { month: "Jun", sales: 34800 },
    { month: "Jul", sales: 36500 }, { month: "Aug", sales: 37900 },
    { month: "Sep", sales: 39200 }, { month: "Oct", sales: 42100 },
    { month: "Nov", sales: 46800 }, { month: "Dec", sales: 51200 }
  ]
};