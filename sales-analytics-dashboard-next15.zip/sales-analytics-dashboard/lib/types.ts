export type SalesRecord = {
  month: string;
  sales: number;
};

export type YearKey = "2022" | "2023" | "2024";

export type SalesDataset = Record<YearKey, SalesRecord[]>;

export type ChartType = "bar" | "line" | "pie";